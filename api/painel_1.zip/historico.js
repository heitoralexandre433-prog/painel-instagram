/**
 * api/historico.js — arquivo dos paineis semanais
 * -----------------------------------------------
 * GET /api/historico            lista os retratos salvos (resumo, sem os posts)
 * GET /api/historico?id=2026-08-24   devolve um retrato inteiro, com os posts
 *
 * Guarda no mesmo Redis (Vercel KV) que ja segura o token.
 *   ig:snaps        -> JSON com a lista de ids, do mais antigo ao mais novo
 *   ig:snap:<id>    -> JSON do retrato daquela semana
 */

const KV = process.env.KV_REST_API_URL;
const KVT = process.env.KV_REST_API_TOKEN;

async function kvGet(k) {
  if (!KV || !KVT) return null;
  try {
    const r = await fetch(`${KV}/get/${encodeURIComponent(k)}`, {
      headers: { Authorization: `Bearer ${KVT}` }
    });
    const j = await r.json();
    return j.result ?? null;
  } catch (e) { return null; }
}

function resumo(s) {
  // devolve o retrato sem a lista de posts, para a listagem ficar leve
  const { posts, ...r } = s || {};
  return { ...r, publicacoes: Array.isArray(posts) ? posts.length : (s && s.publicacoes) || 0 };
}

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');

  if (!KV || !KVT) {
    res.statusCode = 500;
    return res.end(JSON.stringify({ error: 'KV nao configurado' }));
  }

  const id = req.query && req.query.id;

  try {
    if (id) {
      const bruto = await kvGet(`ig:snap:${id}`);
      if (!bruto) { res.statusCode = 404; return res.end(JSON.stringify({ error: 'retrato nao encontrado', id })); }
      res.statusCode = 200;
      return res.end(bruto);
    }

    const ids = JSON.parse((await kvGet('ig:snaps')) || '[]');
    const itens = [];
    for (const x of ids.slice(-60).reverse()) {
      const bruto = await kvGet(`ig:snap:${x}`);
      if (!bruto) continue;
      try { itens.push(resumo(JSON.parse(bruto))); } catch (e) {}
    }

    res.statusCode = 200;
    return res.end(JSON.stringify({ total: itens.length, itens }));
  } catch (e) {
    res.statusCode = 500;
    return res.end(JSON.stringify({ error: 'falha ao ler o arquivo', detalhe: e.message }));
  }
};

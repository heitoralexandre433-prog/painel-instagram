/**
 * api/manutencao.js — roda 1x por dia pelo cron da Vercel
 * -------------------------------------------------------
 *  1. renova o token de longa duracao
 *  2. registra o total de seguidores do dia
 *  3. fecha o retrato da semana quando ela vira (arquivo do painel)
 */

const V = process.env.IG_API_VERSION || 'v21.0';
const KV = process.env.KV_REST_API_URL;
const KVT = process.env.KV_REST_API_TOKEN;

async function kvSet(k, v) {
  const r = await fetch(`${KV}/set/${encodeURIComponent(k)}`, {
    method: 'POST', headers: { Authorization: `Bearer ${KVT}` }, body: String(v)
  });
  return r.ok;
}
async function kvGet(k) {
  const r = await fetch(`${KV}/get/${encodeURIComponent(k)}`, {
    headers: { Authorization: `Bearer ${KVT}` }
  });
  const j = await r.json().catch(() => ({}));
  return j.result ?? null;
}

const dia = d => d.toISOString().slice(0, 10);

/* segunda-feira da semana em que a data cai (UTC) */
function segundaDe(d) {
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dow = x.getUTCDay();              // 0 = domingo
  const recuo = dow === 0 ? 6 : dow - 1;
  x.setUTCDate(x.getUTCDate() - recuo);
  return x;
}

const soma = (l, c) => l.reduce((a, p) => a + (Number(p[c]) || 0), 0);

/* monta o retrato da semana que acabou de fechar */
async function fecharSemana(log) {
  const hoje = new Date();
  const semanaAtual = segundaDe(hoje);
  const inicio = new Date(semanaAtual);           // segunda da semana que fechou
  inicio.setUTCDate(inicio.getUTCDate() - 7);
  const fim = new Date(semanaAtual);
  fim.setUTCDate(fim.getUTCDate() - 1);           // domingo
  const id = dia(inicio);

  const ids = JSON.parse((await kvGet('ig:snaps')) || '[]');
  if (ids.includes(id)) { log.retrato = 'ja existia (' + id + ')'; return; }

  // so fecha depois que a semana terminou de verdade
  if (hoje < semanaAtual) { log.retrato = 'semana ainda aberta'; return; }

  const host = process.env.VERCEL_URL;
  if (!host) { log.erros.push('retrato: VERCEL_URL ausente'); return; }

  const r = await fetch(`https://${host}/api/ig-sync?dias=30`);
  const d = await r.json();
  if (!d || !Array.isArray(d.posts)) { log.erros.push('retrato: ig-sync nao devolveu posts'); return; }

  const de = id, ate = dia(fim);
  const daSemana = d.posts.filter(p => p.data >= de && p.data <= ate);

  const snap = {
    id, de, ate,
    salvoEm: new Date().toISOString(),
    seguidores: Number(d.seguidores) || 0,
    novosSeguidores: d.novosSeguidores == null ? null : Number(d.novosSeguidores),
    visitasPerfil: d.visitasPerfil == null ? null : Number(d.visitasPerfil),
    publicacoes: daSemana.length,
    alcance: soma(daSemana, 'alcance'),
    views: soma(daSemana, 'views'),
    curtidas: soma(daSemana, 'curtidas'),
    comentarios: soma(daSemana, 'comentarios'),
    compartilhamentos: soma(daSemana, 'compartilhamentos'),
    salvamentos: soma(daSemana, 'salvamentos'),
    interacoes: soma(daSemana, 'interacoes'),
    posts: daSemana
  };

  await kvSet(`ig:snap:${id}`, JSON.stringify(snap));
  ids.push(id);
  await kvSet('ig:snaps', JSON.stringify(ids.slice(-156)));   // 3 anos de semanas
  log.retrato = `semana ${de} a ${ate} arquivada · ${daSemana.length} publicacao(oes)`;
}

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  const log = { em: new Date().toISOString(), token: null, seguidores: null, retrato: null, erros: [] };

  if (!KV || !KVT) { res.statusCode = 500; return res.end(JSON.stringify({ error: 'KV nao configurado' })); }

  const tk = (await kvGet('ig:token')) || process.env.IG_TOKEN || process.env.IG_ACCESS_TOKEN;
  const id = process.env.IG_USER_ID;
  if (!tk || !id) { res.statusCode = 500; return res.end(JSON.stringify({ error: 'faltam IG_TOKEN/IG_USER_ID' })); }

  let atual = tk;

  // 1) renova o token (a Meta permite a partir de 24h de vida)
  try {
    const r = await fetch(`https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token=${tk}`);
    const j = await r.json();
    if (j.access_token) {
      atual = j.access_token;
      await kvSet('ig:token', atual);
      await kvSet('ig:token_em', new Date().toISOString());
      log.token = `renovado (expira em ${Math.round((j.expires_in || 0) / 86400)} dias)`;
    } else {
      log.token = 'nao renovado';
      log.erros.push((j.error && j.error.message) || 'resposta sem access_token');
    }
  } catch (e) { log.erros.push('refresh: ' + e.message); }

  // 2) registra o total de seguidores do dia
  try {
    const r = await fetch(`https://graph.instagram.com/${V}/${id}?fields=followers_count&access_token=${atual}`);
    const j = await r.json();
    if (typeof j.followers_count === 'number') {
      const hoje = dia(new Date());
      await kvSet(`ig:seg:${hoje}`, j.followers_count);
      const hist = JSON.parse((await kvGet('ig:hist')) || '[]');
      if (!hist.length || hist[hist.length - 1].d !== hoje) hist.push({ d: hoje, v: j.followers_count });
      else hist[hist.length - 1].v = j.followers_count;
      await kvSet('ig:hist', JSON.stringify(hist.slice(-120)));
      log.seguidores = j.followers_count;
    } else {
      log.erros.push((j.error && j.error.message) || 'sem followers_count');
    }
  } catch (e) { log.erros.push('seguidores: ' + e.message); }

  // 3) fecha o retrato da semana, se ainda nao existir
  try { await fecharSemana(log); }
  catch (e) { log.erros.push('retrato: ' + e.message); }

  res.statusCode = 200;
  res.end(JSON.stringify(log));
};
